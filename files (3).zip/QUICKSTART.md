# 5-Minute Quickstart

## Step 1: Create Repository (1 min)
1. Go to GitHub.com
2. Click "+" → "New repository"
3. Name: `auracelle-charlie`
4. Public, no README
5. Create

## Step 2: Upload Files (2 min)
1. Click "uploading an existing file"
2. Drag ALL files into browser
3. Commit: "Initial commit"

## Step 3: Enable GitHub Pages (1 min)
1. Settings → Pages
2. Source: `main` branch
3. Save

## Step 4: Wait (1 min)
- Wait 2-3 minutes for deployment

## Step 5: View! (30 seconds)
Visit: `https://YOUR_USERNAME.github.io/auracelle-charlie/`

---

## That's it! 🎉

Your Strategic Intelligence Sandbox is live!
